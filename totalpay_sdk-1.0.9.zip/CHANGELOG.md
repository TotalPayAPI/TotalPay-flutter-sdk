## 1.0.9

. Enhancement and fixed the validations
. Enable http logs using enableDebug Boolean argument of TotalPaySdk initialization method `TotalpaySdk.instance.config`
