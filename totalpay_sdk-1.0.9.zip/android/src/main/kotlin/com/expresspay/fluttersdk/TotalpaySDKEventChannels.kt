package com.totalpay.fluttersdk

import android.content.Context
import com.totalpay.fluttersdk.eventhandlers.*
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.EventChannel

/** TotalpaySdkPlugin */
class TotalpaySDKEventChannels{

  var cardpay:EventChannel? = null;
  var applepay:EventChannel? = null;

  var sale:EventChannel? = null;
  var recurringSale:EventChannel? = null;
  var capture:EventChannel? = null;
  var creditVoid:EventChannel? = null;
  var transactionStatus:EventChannel? = null;
  var transactionDetail:EventChannel? = null;
  var transactionLogs:EventChannel? = null;


  public fun initiate(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding, context: Context) {
    val messenger = flutterPluginBinding.binaryMessenger

    cardpay = EventChannel(messenger,"com.totalpay.sdk.cardpay")
    sale = EventChannel(messenger,"com.totalpay.sdk.sale")
    recurringSale = EventChannel(messenger,"com.totalpay.sdk.recurringsale")
    capture = EventChannel(messenger,"com.totalpay.sdk.capture")
    creditVoid = EventChannel(messenger,"com.totalpay.sdk.creditvoid")
    transactionStatus = EventChannel(messenger,"com.totalpay.sdk.transactionstatus")
    transactionDetail = EventChannel(messenger,"com.totalpay.sdk.transactiondetail")
    transactionLogs = EventChannel(messenger,"com.totalpay.sdk.transactionlogs")

    sale?.setStreamHandler(SaleEventHandler())
    recurringSale?.setStreamHandler(RecurringSaleEventHandler())
    capture?.setStreamHandler(CaptureEventHandler())
    creditVoid?.setStreamHandler(CreditVoidEventHandler())
    transactionStatus?.setStreamHandler(GetTransactionStatusEventHandler())
    transactionDetail?.setStreamHandler(GetTransactionDetailsEventHandler())
    cardpay?.setStreamHandler(CardPayEventHandler(context))

  }
}
