package com.totalpay.fluttersdk.eventhandlers

import android.content.Context
import com.totalpay.fluttersdk.helper.Helper
import com.totalpay.fluttersdk.helper.toMap
import com.totalpay.sdk.model.request.order.TotalpaySaleOrder
import com.totalpay.sdk.model.request.payer.TotalpayPayer
import com.totalpay.sdk.model.response.base.error.TotalpayError
import com.totalpay.sdk.model.response.base.result.ITotalpayResult
import com.totalpay.sdk.model.response.gettransactiondetails.TotalpayGetTransactionDetailsSuccess
import com.totalpay.sdk.views.totalcardpay.TotalCardPay
import com.google.gson.Gson
import io.flutter.embedding.android.FlutterActivity
import io.flutter.plugin.common.EventChannel
import java.io.Serializable

class CardPayEventHandler(private val context: Context): EventChannel.StreamHandler {
    var sink:EventChannel.EventSink? = null

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        sink = events

        (arguments as? Map<*, *>)?.let {
            with(it) {
                (get("TotalpaySaleOrder") as? Map<*, *>)?.let { orderMap ->
                    (get("TotalpayPayer") as? Map<*, *>)?.let { payerMap ->
                        val order = Gson().fromJson(Gson().toJson(orderMap), TotalpaySaleOrder::class.java)
                        val payer = Gson().fromJson(Gson().toJson(payerMap), TotalpayPayer::class.java)
                        payWithCard(order, payer)
                    }
                }
            }
        }

    }

    override fun onCancel(arguments: Any?) {

    }

    fun payWithCard(order:TotalpaySaleOrder, payer:TotalpayPayer){

        val totalCardPay = TotalCardPay()
            .setOrder(order)
            .setPayer(payer)
            .onTransactionFailure { res, data ->
                print("$res $data")
                handleFailure(data!!)
            }.onTransactionSuccess { res, data ->
                print("$res $data")
                handleSuccess(data as? TotalpayGetTransactionDetailsSuccess)
            }

        /*
        * Precise way to start card payment (ready to use)
        * */
        totalCardPay.initialize(
            context,
            onError = {
                handleFailure(it)
            },
            onPresent = {
                onPresent()
            }
        )


        /*
        * To get intent of card screen activity to present in your own choice (ready to use)
        * */
//        startActivity(totalCardPay.intent(
//            this,
//            onError = {
//
//            },
//            onPresent = {
//
//            })
//        )


        /*
        * To get fragment of card screen to present in your own choice (ready to use)
        * */
//        totalCardPay.fragment(
//            onError = {
//
//            },
//            onPresent = {
//
//            }
//        )
    }



    private fun onPresent(){
        print("onPresent :)")
        sink?.success(
            mapOf(
                "onPresent" to ":)"
            )
        )
    }

    private fun handleSuccess(response: TotalpayGetTransactionDetailsSuccess?){
        print("native.transactionSuccess.data ==> ${response?.toMap()}")
        sink?.success(
            mapOf(
                "success" to response?.toMap()
            )
        )
    }

    private fun handleFailure(error:Any){
        when (error) {
            is  TotalpayError -> sink?.success(
                mapOf("error" to error.toMap())
            )
            is Serializable -> sink?.success(
                mapOf("failure" to error.toMap())
            )
            else -> sink?.success(
                mapOf(
                    "error" to mapOf(
                        "result" to "ERROR",
                        "error_code" to 100000,
                        "error_message" to "$error",
                        "errors" to listOf<Map<*,*>>(),
                    )
                )
            )

        }
    }
}