package com.totalpay.fluttersdk.eventhandlers

import com.totalpay.sdk.core.TotalpaySdk
import com.totalpay.fluttersdk.helper.toMap
import com.totalpay.sdk.TotalPayHomeActivity_
import com.totalpay.sdk.model.request.card.TotalpayCard
import com.totalpay.sdk.model.request.options.TotalpaySaleOptions
import com.totalpay.sdk.model.request.order.TotalpaySaleOrder
import com.totalpay.sdk.model.request.payer.TotalpayPayer
import com.totalpay.sdk.model.response.base.TotalpayResponse
import com.totalpay.sdk.model.response.base.error.TotalpayError
import com.totalpay.sdk.model.response.sale.*
import com.google.gson.Gson
import io.flutter.plugin.common.EventChannel
import kotlin.math.sin


class SaleEventHandler: EventChannel.StreamHandler {
    var sink:EventChannel.EventSink? = null

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        sink = events

        (arguments as? Map<*, *>)?.let {
            print(
                with(it) {
                    (get("TotalpaySaleOrder") as? Map<*, *>)?.let { orderMap ->
                        (get("TotalpayPayer") as? Map<*, *>)?.let { payerMap ->
                            (get("TotalpayCard") as? Map<*, *>)?.let { cardMap ->
                                (get("auth") as? Boolean)?.let { auth ->

                                    val order = Gson().fromJson(Gson().toJson(orderMap), TotalpaySaleOrder::class.java)
                                    val payer = Gson().fromJson(Gson().toJson(payerMap), TotalpayPayer::class.java)
                                    val card = Gson().fromJson(Gson().toJson(cardMap), TotalpayCard::class.java)

                                    var options:TotalpaySaleOptions? = null
                                    (get("TotalpaySaleOption") as? Map<*, *>)?.let {
                                        options = Gson().fromJson(Gson().toJson(payerMap), TotalpaySaleOptions::class.java)
                                    }

                                    sale(auth = auth, order = order, payer = payer, card = card, saleOptions = options)

                                    "All params are valid"
                                } ?: "Missing 'Boolean' auth parameter"
                            } ?: "Missing 'TotalpayCard' parameter"
                        } ?: "Missing 'TotalpayPayer' parameter"
                    } ?: "Missing 'TotalpaySaleOrder' parameter"
                }
            )
        }

    }

    override fun onCancel(arguments: Any?) {
    }

    fun sale(auth:Boolean, order:TotalpaySaleOrder, payer:TotalpayPayer, card:TotalpayCard, saleOptions:TotalpaySaleOptions?){
        TotalpaySdk.Adapter.SALE.execute(
            order = order,
            card = card,
            payer = payer,
            termUrl3ds = "https://pay.totalpay.sa/",
            options = saleOptions,
            auth = auth,
            callback = object : TotalpaySaleCallback {
                override fun onResponse(response: TotalpaySaleResponse) {
                    send(mapOf("responseJSON" to response.toMap()))
                    super.onResponse(response)
                }

                override fun onResult(result: TotalpaySaleResult) {
                    val res = result.result
                    when (res) {
                        is TotalpaySaleDecline -> send(mapOf("decline" to res.toMap()))
                        is TotalpaySaleRecurring -> send(mapOf("recurring" to res.toMap()))
                        is TotalpaySaleRedirect -> send(mapOf("redirect" to res.toMap()))
                        is TotalpaySale3Ds -> send(mapOf("secure3d" to res.toMap()))
                        is TotalpaySaleSuccess -> send(mapOf("success" to res.toMap()))
                    }
                }

                override fun onError(error: TotalpayError){
                    send(mapOf("error" to error.toMap()))
                }

                override fun onFailure(throwable: Throwable) {
                    send(mapOf("failure" to throwable.toMap()))
                    super.onFailure(throwable)
                }
            }
        )

    }
    private fun send(map:Map<*,*>){
        sink?.success(map)
    }
}