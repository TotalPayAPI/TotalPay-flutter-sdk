package com.totalpay.fluttersdk.helper

import com.totalpay.sdk.model.response.base.TotalpayResponse
import com.google.gson.Gson
import java.io.Serializable


fun Serializable.toJSON() = Gson().toJson(this)
fun Serializable.toMap() = Gson().fromJson(toJSON(), Map::class.java)
fun Serializable.fromJSON(json:String) = Gson().fromJson(json, this::class.java)


fun TotalpayResponse<*>.toMap() : Map<*,*>?{
    return  (this as? TotalpayResponse.Error)?.let {
        it.error.toMap()
    } ?: (this as? TotalpayResponse.Result)?.let {
        Gson().fromJson(it.jsonObject, Map::class.java)
    }
}