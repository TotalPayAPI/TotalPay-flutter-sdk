package com.totalpay.fluttersdk.methodhandlers

import android.content.Context
import com.totalpay.fluttersdk.ENABLE_DEBUG
import com.totalpay.sdk.core.TotalpaySdk
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel


class ConfigMethodHandler(private val context:Context, private val call:MethodCall, private val result: MethodChannel.Result) {

    fun handle(){
        (call.arguments as? List<*>)?.let {
            with(it) {
                (get(0) as? String)?.let { key ->
                    (get(1) as? String)?.let { password ->
                        TotalpaySdk.init(context, key, password, "https://api.totalpay.com/post")
                        (get(2) as? Boolean)?.let { enableDebug ->
                            ENABLE_DEBUG = enableDebug
                            if(ENABLE_DEBUG)
                                TotalpaySdk.enableDebug()
                            else
                                TotalpaySdk.disableDebug()
                        }
                    }
                }
            }
        }
    }

}