package com.totalpay.fluttersdk.methodhandlers

import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel


class PlatformVersionMethodHandler(private val call:MethodCall, private val result: MethodChannel.Result) {

    fun handle(){

    }
}