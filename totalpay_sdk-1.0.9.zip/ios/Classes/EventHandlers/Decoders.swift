//
//  Codables.swift
//  totalpay_sdk
//
//  Created by Zohaib Kambrani on 03/03/2023.
//

import Foundation
import TotalPaySDK



extension TotalPaySaleOrder{
    static func from(dictionary:[String:Any?]) -> TotalPaySaleOrder{
        return TotalPaySaleOrder(
            id: dictionary["id"] as? String ?? "",
            amount: dictionary["amount"] as? Double ?? 0.0,
            currency: dictionary["currency"] as? String ?? "",
            description: dictionary["description"] as? String ?? ""
        )
    }
}

extension TotalPayOrder{
    static func from_(dictionary:[String:Any?]) -> TotalPayOrder{
        return TotalPayOrder(
            id: dictionary["id"] as? String ?? "",
            amount: dictionary["amount"] as? Double ?? 0.0,
            description: dictionary["description"] as? String ?? ""
        )
    }
}

extension TotalPayPayer{
    static func from(dictionary:[String:Any?]) -> TotalPayPayer{
        
        return TotalPayPayer(
            firstName:  dictionary["firstName"] as? String ?? "",
            lastName: dictionary["lastName"] as? String ?? "",
            address: dictionary["address"] as? String ?? "",
            country: dictionary["country"] as? String ?? "",
            city: dictionary["city"] as? String ?? "",
            zip: dictionary["zip"] as? String ?? "",
            email: dictionary["email"] as? String ?? "",
            phone: dictionary["phone"] as? String ?? "",
            ip: dictionary["ip"] as? String ?? "",
            options: TotalPayPayerOptions.from(dictionary: dictionary["options"] as? [String : Any?])
        )
    }
}


extension TotalPayPayerOptions{
    static func from(dictionary:[String:Any?]?) -> TotalPayPayerOptions?{
        if let s = dictionary{
            return TotalPayPayerOptions(
               middleName: s["middleName"] as? String ?? "",
               birthdate: TotalPayDateFormatter().toDate(dob: s["birthdate"] as? String),
               address2: s["address2"] as? String ?? "",
               state: s["state"] as? String ?? ""
           )
        }
        return nil
        
    }
}


extension TotalPayRecurringOptions{
    static func from(dictionary:[String:Any?]) -> TotalPayRecurringOptions{
        return TotalPayRecurringOptions(
           firstTransactionId: dictionary["firstTransactionId"] as? String ?? "",
           token: dictionary["token"] as? String ?? ""
       )
    }
}

extension TotalPayCard{
    static func from(dictionary:[String:Any?]) -> TotalPayCard{
        return TotalPayCard(
            number: dictionary["number"] as? String ?? "",
            expireMonth: dictionary["expireMonth"] as? Int ?? 0,
            expireYear:  dictionary["expireYear"] as? Int ?? 0,
            cvv: dictionary["cvv"] as? String ?? ""
        )
    }
}
