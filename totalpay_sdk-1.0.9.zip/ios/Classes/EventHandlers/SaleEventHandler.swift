//
//  SaleEventHandler.swift
//  totalpay_sdk
//
//  Created by Zohaib Kambrani on 03/03/2023.
//

import Foundation
import Flutter
import UIKit
import TotalPaySDK


class SaleEventHandler : NSObject, FlutterStreamHandler{
    
    var eventSink:FlutterEventSink? = nil
    
    private lazy var saleAdapter: TotalPaySaleAdapter = {
        let adapter = TotalPayAdapterFactory().createSale()
        adapter.delegate = self
        return adapter
    }()
    
    
    public func onListen(withArguments arguments: Any?, eventSink events: @escaping FlutterEventSink) -> FlutterError? {
        eventSink = events
        
        if let params = arguments as? [String:Any],
           let auth = params["auth"] as? Bool,
           let order = params["TotalpaySaleOrder"] as? [String : Any?],
           let card = params["TotalpayCard"] as? [String : Any?],
           let payer =  params["TotalpayPayer"] as? [String : Any?]{
                 
            saleAdapter.delegate = self
            saleAdapter.execute(
                order: TotalPaySaleOrder.from(dictionary: order),
                card: TotalPayCard.from(dictionary: card),
                payer: TotalPayPayer.from(dictionary: payer),
                termUrl3ds: "https://totalpay.sa",
                options: nil,
                auth: auth,
                callback: handleResponse
            )
            
        }
        return nil
    }
    
    public func onCancel(withArguments arguments: Any?) -> FlutterError? {
        return nil
    }
    
    private func handleResponse(response: TotalPayResponse<TotalPaySaleResult>){
        
        switch response {
        case .result(let result):
            
            switch result {
            case .recurring(let result):
                let json = result.toJSON(root: "recurring")
                eventSink?(json)
                
            case .secure3d(let result):
                let json = result.toJSON(root: "secure3d")
                eventSink?(json)
                
            case .redirect(let result):
                let json = result.toJSON(root: "redirect")
                eventSink?(json)
                
            case .success(let result):
                let json = result.toJSON(root: "success")
                eventSink?(json)
                
            case .decline(let result):
                let json = result.toJSON(root: "decline")
                eventSink?(json)

            default: break
                let json = ["failure" : ["error" : "Unhandled response case at TotalPaySaleResult.result"]]
                eventSink?(json)
                
            }
                        
        case .error(let error):
            let json = ["error" : error.json()]
            eventSink?(json)
            print(error)
            
        case .failure(let exception):
            if let err = exception as? NSError{
                let json = ["failure" : err.userInfo]
                eventSink?(json)
            }else{
                let json = ["failure" : ["exception" : exception.localizedDescription]]
                eventSink?(json)
            }
            print(exception)
            
        default:
            let json = ["failure" : ["error" : "Unhandled response case at TotalPayResponse.result"]]
            eventSink?(json)
        }
    }
    
}

extension SaleEventHandler : TotalPayAdapterDelegate{
    
    func willSendRequest(_ request: TotalPayDataRequest) {
        
    }
    
    func didReceiveResponse(_ reponse: TotalPayDataResponse?) {
        if let data = reponse?.data,
           let dict = try? JSONSerialization.jsonObject(with: data, options: .fragmentsAllowed){
            eventSink?(["responseJSON" : dict])
        }
    }
    
}


