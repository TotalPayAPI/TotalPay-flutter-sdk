//
//  TotalPaySDK.h
//  TotalPaySDK
//
//  Created by Zohaib Kambrani on 26/01/2023.
// To Archive the Framework (xcodebuild archive)
// To Clean/Build/Arvice the Framework  (xcodebuild -project TotalPaySDK.xcodeproj -scheme TotalPaySDK -configuration Release CONFIGURATION_BUILD_DIR=. clean build)


/*
// Could not find module 'TotalPaySDK' for target 'arm64-apple-ios-simulator'; found: arm64-apple-ios, at: /Volumes/EdfaPay/Codes/Github/TotalPay/iOS/totalpay-ios-sdk-framework/TotalPaySDK.framework/Modules/TotalPaySDK.swiftmodule


// Archive Framework for Simulator
xcodebuild archive \
-scheme TotalPaySDK \
-configuration Release \
-destination 'generic/platform=iOS Simulator' \
-archivePath './build/TotalPaySDK.framework-iphonesimulator.xcarchive' \
SKIP_INSTALL=NO \
BUILD_LIBRARIES_FOR_DISTRIBUTION=YES


// Archive Framework for iOS
xcodebuild archive \
-scheme TotalPaySDK \
-configuration Release \
-destination 'generic/platform=iOS' \
-archivePath './build/TotalPaySDK.framework-iphoneos.xcarchive' \
SKIP_INSTALL=NO \
BUILD_LIBRARIES_FOR_DISTRIBUTION=YES

*/

#import <Foundation/Foundation.h>

//! Project version number for TotalPaySDK.
FOUNDATION_EXPORT double TotalPaySDKVersionNumber = 2;

//! Project version string for TotalPaySDK.
FOUNDATION_EXPORT const unsigned char TotalPaySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like


