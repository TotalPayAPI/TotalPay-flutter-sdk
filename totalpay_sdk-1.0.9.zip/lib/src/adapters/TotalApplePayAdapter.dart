import 'dart:convert';

import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/Helpers.dart';
import 'package:totalpay_sdk/src/adapters/BaseAdapter.dart';
import 'package:totalpay_sdk/src/applepay/TotalApplePayResult.dart';

import 'callbacks/ApplePayResponseCallback.dart';

class TotalApplePayAdapter extends BaseAdapter {
  execute({
    required String applePayMerchantId,
    required TotalpaySaleOrder order,
    required TotalpayPayer payer,
    required ApplePayResponseCallback? callback,
    Function(dynamic)? onFailure,
  }) {
    final params = {
      order.runtimeType.toString(): order.toJson(),
      payer.runtimeType.toString(): payer.toJson(),
      "applePayMerchantId": applePayMerchantId,
    };

    startApplePay(params).listen((event) {
      Log(event);
      TotalApplePayResult(event).triggerCallbacks(callback);
    });

    Log("[TotalpaySaleAdapter.execute][Params] ${jsonEncode(params)}");
  }
}
