import 'dart:convert';

import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/BaseAdapter.dart';
import 'package:totalpay_sdk/src/adapters/callbacks/CardPayResponseCallback.dart';
import 'package:totalpay_sdk/src/cardpay/TotalCardPayResult.dart';
import 'package:totalpay_sdk/src/Helpers.dart';

class TotalCardPayAdapter extends BaseAdapter {
  execute({
    required TotalpaySaleOrder order,
    required TotalpayPayer payer,
    required CardPayResponseCallback? callback,
    Function(dynamic)? onFailure,
  }) {
    final params = {
      order.runtimeType.toString(): order.toJson(),
      payer.runtimeType.toString(): payer.toJson(),
    };

    startCardPay(params).listen((event) {
      Log(event);
      TotalCardPayResult(event).triggerCallbacks(callback);
    });

    Log("[TotalpaySaleAdapter.execute][Params] ${jsonEncode(params)}");
  }
}
