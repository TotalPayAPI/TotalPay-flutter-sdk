import 'package:totalpay_sdk/src/adapters/TotalApplePayAdapter.dart';
import 'package:totalpay_sdk/src/adapters/TotalCardPayAdapter.dart';
import 'package:totalpay_sdk/src/adapters/TotalPayGetTransactionDetailsAdapter.dart';
import 'package:totalpay_sdk/src/adapters/TotalPayGetTransactionStatusAdapter.dart';

import 'TotalPayCaptureAdapter.dart';
import 'TotalPayCreditVoidAdapter.dart';
import 'TotalPayRecurringSaleAdapter.dart';
import 'TotalPaySaleAdapter.dart';

class TotalPayAdapters {
  final CARD_PAY = TotalCardPayAdapter();
  final APPLE_PAY = TotalApplePayAdapter();

  final SALE = TotalPaySaleAdapter();
  final RECURRING_SALE = TotalPayRecurringSaleAdapter();
  final CAPTURE = TotalPayCaptureAdapter();
  final CREDIT_VOID = TotalPayCreditVoidAdapter();
  final TRANSACTION_STATUS = TotalPayGetTransactionStatusAdapter();
  final TRANSACTION_DETAILS = TotalPayGetTransactionDetailsAdapter();
}
