import 'dart:convert';

import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/BaseAdapter.dart';
import 'package:totalpay_sdk/src/Helpers.dart';

class TotalPayCreditVoidAdapter extends BaseAdapter {
  // transactionId = selectedTransaction.id,
  // payerEmail = selectedTransaction.payerEmail,
  // cardNumber = selectedTransaction.cardNumber,
  // amount = amount,
  execute({
    required String transactionId,
    required String payerEmail,
    required String cardNumber,
    required double? amount,
    required CreditVoidResponseCallback? onResponse,
    required Function(dynamic)? onFailure,
    required Function(Map)? onResponseJSON,
  }) {
    final params = {
      "transactionId": transactionId,
      "payerEmail": payerEmail,
      "cardNumber": cardNumber,
      "amount": amount,
    };

    startCreditVoid(params).listen((event) {
      Log(event);
      TotalpayCreditVoidResult(event).triggerCallbacks(
        onResponse,
        onResponseJSON: onResponseJSON,
      );
    });

    Log("[TotalpayCreditVoidAdapter.execute][Params] ${jsonEncode(params)}");
  }
}
