import 'dart:convert';

import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/BaseAdapter.dart';
import 'package:totalpay_sdk/src/Helpers.dart';

class TotalPayGetTransactionDetailsAdapter extends BaseAdapter {
  // transactionId = selectedTransaction.id,
  // payerEmail = selectedTransaction.payerEmail,
  // cardNumber = selectedTransaction.cardNumber,
  // amount = amount,
  execute({
    required String transactionId,
    required String payerEmail,
    required String cardNumber,
    required TransactionDetailsResponseCallback? onResponse,
    required Function(dynamic)? onFailure,
    required Function(Map)? onResponseJSON,
  }) {
    final params = {
      "transactionId": transactionId,
      "payerEmail": payerEmail,
      "cardNumber": cardNumber,
    };

    startTransactionsDetail(params).listen((event) {
      Log(event);
      TotalpayTransactionDetailResult(event)
          .triggerCallbacks(onResponse, onResponseJSON: onResponseJSON);
    });

    Log("[TotalpayTransactionDetailAdapter.execute][Params] ${jsonEncode(params)}");
  }
}
