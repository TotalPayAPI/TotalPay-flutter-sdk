import 'dart:convert';

import 'package:totalpay_sdk/src/adapters/BaseAdapter.dart';
import 'package:totalpay_sdk/src/adapters/callbacks/TransactionStatusResponseCallback.dart';
import 'package:totalpay_sdk/src/response/gettransactionstatus/TotalpayTransactionStatusResult.dart';
import 'package:totalpay_sdk/src/Helpers.dart';

class TotalPayGetTransactionStatusAdapter extends BaseAdapter {
  // transactionId = selectedTransaction.id,
  // payerEmail = selectedTransaction.payerEmail,
  // cardNumber = selectedTransaction.cardNumber,
  // amount = amount,
  execute({
    required String transactionId,
    required String payerEmail,
    required String cardNumber,
    required TransactionStatusResponseCallback? onResponse,
    required Function(dynamic)? onFailure,
    required Function(Map)? onResponseJSON,
  }) {
    final params = {
      "transactionId": transactionId,
      "payerEmail": payerEmail,
      "cardNumber": cardNumber,
    };

    startTransactionsStatus(params).listen((event) {
      Log(event);
      TotalpayTransactionStatusResult(event).triggerCallbacks(
        onResponse,
        onResponseJSON: onResponseJSON,
      );
    });

    Log("[TotalpayTransactionStatusAdapter.execute][Params] ${jsonEncode(params)}");
  }
}
