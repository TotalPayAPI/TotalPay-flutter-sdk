import 'dart:convert';

import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/BaseAdapter.dart';
import 'package:totalpay_sdk/src/Helpers.dart';

class TotalPayRecurringSaleAdapter extends BaseAdapter {
  // order = order,
  // options = recurringOptions,
  // payerEmail = selectedTransaction.payerEmail,
  // cardNumber = selectedTransaction.cardNumber,
  // auth = isAuth,

  execute({
    required TotalpayOrder order,
    required TotalpayRecurringOptions recurringOptions,
    required String payerEmail,
    required String cardNumber,
    required bool isAuth,
    required RecurringSaleResponseCallback? onResponse,
    required Function(dynamic)? onFailure,
    required Function(Map)? onResponseJSON,
  }) {
    final params = {
      order.runtimeType.toString(): order.toJson(),
      recurringOptions.runtimeType.toString(): recurringOptions.toJson(),
      "payerEmail": payerEmail,
      "cardNumber": cardNumber,
      "auth": isAuth,
    };

    startRecurringSale(params).listen((event) {
      Log(event);
      TotalpaySaleResult(event).triggerCallbacks(
        onResponse,
        onResponseJSON: onResponseJSON,
      );
    });

    Log("[TotalpayRecurringSaleAdapter.execute][Params] ${jsonEncode(params)}");
  }
}
