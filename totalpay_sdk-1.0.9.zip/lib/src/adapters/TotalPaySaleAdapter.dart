import 'dart:convert';

import 'package:totalpay_sdk/src/adapters/BaseAdapter.dart';

import '../../totalpay_sdk.dart';
import 'package:totalpay_sdk/src/Helpers.dart';

class TotalPaySaleAdapter extends BaseAdapter {
  execute({
    required TotalpaySaleOrder order,
    required TotalpayCard card,
    required TotalpayPayer payer,
    TotalpaySaleOption? saleOption,
    required bool isAuth,
    required SaleResponseCallback? onResponse,
    required Function(dynamic)? onFailure,
    required Function(Map)? onResponseJSON,
  }) {
    final params = {
      card.runtimeType.toString(): card.toJson(),
      order.runtimeType.toString(): order.toJson(),
      payer.runtimeType.toString(): payer.toJson(),
      "auth": isAuth,
      if (saleOption != null) card.runtimeType.toString(): saleOption.toJson(),
    };

    startSale(params).listen((event) {
      Log(event);
      TotalpaySaleResult(event).triggerCallbacks(onResponse,
          onResponseJSON: onResponseJSON, onFailure: onFailure);
    });

    Log("[TotalpaySaleAdapter.execute][Params] ${jsonEncode(params)}");
  }
}
