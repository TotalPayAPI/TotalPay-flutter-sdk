import 'package:totalpay_sdk/totalpay_sdk.dart';

class BaseResponseCallback {
  final Function(TotalpayError result) error;

  BaseResponseCallback({required this.error});
}
