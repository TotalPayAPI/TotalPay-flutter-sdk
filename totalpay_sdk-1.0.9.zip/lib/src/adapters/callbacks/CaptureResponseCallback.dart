import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';

class CaptureResponseCallback extends BaseResponseCallback {
  final Function(TotalpayCaptureSuccess result) success;
  final Function(TotalpayCaptureDecline result) decline;

  CaptureResponseCallback(
      {required this.success, required this.decline, required super.error});
}
