import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';

class CardPayResponseCallback extends BaseResponseCallback {
  final Function(TotalpayTransactionDetailsSuccess result) success;
  final Function(TotalpayTransactionDetailsSuccess result) failure;

  CardPayResponseCallback(
      {required this.success, required this.failure, required super.error});
}
