import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';

class CreditVoidResponseCallback extends BaseResponseCallback {
  final Function(TotalpayCreditVoidSuccess result) success;

  CreditVoidResponseCallback({required this.success, required super.error});
}
