import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';
import 'package:totalpay_sdk/src/response/gettransactiondetails/TotalpayTransactionDetailsSuccess.dart';

class TransactionDetailsResponseCallback extends BaseResponseCallback {
  final Function(TotalpayTransactionDetailsSuccess result) success;

  TransactionDetailsResponseCallback(
      {required this.success, required super.error});
}
