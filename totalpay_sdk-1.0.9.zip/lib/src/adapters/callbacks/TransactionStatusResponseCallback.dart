import 'package:totalpay_sdk/src/adapters/callbacks/BaseResponseCallback.dart';
import 'package:totalpay_sdk/src/response/gettransactionstatus/TotalpayTransactionStatusSuccess.dart';

class TransactionStatusResponseCallback extends BaseResponseCallback {
  final Function(TotalpayTransactionStatusSuccess result) success;

  TransactionStatusResponseCallback(
      {required this.success, required super.error});
}
