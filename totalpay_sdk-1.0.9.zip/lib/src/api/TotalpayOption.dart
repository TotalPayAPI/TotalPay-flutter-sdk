/*
 * Property of Totalpay (https://totalpay.sa).
 */

/// "Y" or "N" value holder.
///
/// @property option the option value.
enum TotalpayOption {
  /// "Y" value.
  YES("Y"),

  /// "N" value.
  NO("N");

  final String option;
  const TotalpayOption(this.option);

  factory TotalpayOption.of(String? id) {
    return values.firstWhere((e) => e.option == id);
  }
}
