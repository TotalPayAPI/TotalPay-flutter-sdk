/*
 * Property of Totalpay (https://totalpay.sa).
 */

/// The method of transferring parameters (POST/GET).
/// @see com.totalpay.sdk.model.response.sale.TotalpaySale3Ds
///
/// @property redirectMethod the redirect method value.
enum TotalpayRedirectMethod {
  /// GET redirect method value.
  GET("GET"),

  /// POST redirect method value.
  POST("POST");

  final String redirectMethod;
  const TotalpayRedirectMethod(this.redirectMethod);

  factory TotalpayRedirectMethod.of(String? id) {
    return values.firstWhere((e) => e.redirectMethod == id);
  }
}
