import 'package:collection/collection.dart';

/*
 * Property of Totalpay (https://totalpay.sa).
 */

/// Result – value that system returns on request.
/// @see com.totalpay.sdk.model.response.base.result.ITotalpayResult
///
/// @property result the result value.
enum TotalpayResult {
  /// Action was successfully completed  in Payment Platform.
  SUCCESS("SUCCESS"),

  /// Result of unsuccessful action in Payment Platform.
  DECLINED("DECLINED"),

  /// Additional action required from requester (Redirect to 3ds).
  REDIRECT("REDIRECT"),

  /// Action was accepted by Payment Platform, but will be completed later.
  ACCEPTED("ACCEPTED"),

  /// Request has errors and was not validated by Payment Platform.
  ERROR("ERROR"),

  NONE("NONE");

  final String result;
  const TotalpayResult(this.result);

  factory TotalpayResult.of(String? id) {
    return values.firstWhereOrNull((e) => e.result == id) ?? NONE;
  }
}
