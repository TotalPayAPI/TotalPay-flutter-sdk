/*
 * Property of Totalpay (https://totalpay.sa).
 */

/// The transaction status types.
/// @see com.totalpay.sdk.model.response.gettransactiondetails.TotalpayTransaction
///
/// @property transactionStatus the transaction status value.
enum TotalpayTransactionStatus {
  /// Failed or "0" status.
  FAIL("fail"),

  /// Success or "1" status.
  SUCCESS("success");

  final String transactionStatus;
  const TotalpayTransactionStatus(this.transactionStatus);

  factory TotalpayTransactionStatus.of(String? id) {
    return values.firstWhere((e) => e.transactionStatus == id);
  }
}
