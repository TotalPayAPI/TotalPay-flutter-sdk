/*
 * Property of Totalpay (https://totalpay.sa).
 */

/// The transaction type types.
/// @see com.totalpay.sdk.model.response.gettransactiondetails.TotalpayTransaction
///
/// @property transactionType the transaction type value.
enum TotalpayTransactionType {
  /// 3DS transaction type.
  SECURE_3D("3DS"),

  /// SALE transaction type.
  SALE("SALE"),

  /// AUTH transaction type.
  AUTH("AUTH"),

  /// CAPTURE transaction type.
  CAPTURE("CAPTURE"),

  /// REVERSAL transaction type.
  REVERSAL("REVERSAL"),

  /// REFUND transaction type.
  REFUND("REFUND"),

  /// REDIRECT transaction type.
  REDIRECT("REDIRECT"),

  /// CHARGEBACK transaction type.
  CHARGEBACK("CHARGEBACK");

  final String transactionType;
  const TotalpayTransactionType(this.transactionType);

  factory TotalpayTransactionType.of(String? id) {
    return values.firstWhere((e) => e.transactionType == id);
  }
}
