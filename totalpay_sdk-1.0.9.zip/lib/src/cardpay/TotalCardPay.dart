import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/callbacks/CardPayResponseCallback.dart';
import 'package:flutter/cupertino.dart';
import 'package:totalpay_sdk/src/Helpers.dart';

class TotalCardPay {
  Function(TotalpayTransactionDetailsSuccess response)? _onTransactionFailure;
  Function(TotalpayTransactionDetailsSuccess response)? _onTransactionSuccess;
  Function(dynamic)? _onError;
  Function(BuildContext)? _onPresent;

  TotalpaySaleOrder? _order;
  TotalpayPayer? _payer;

  TotalCardPay setOrder(TotalpaySaleOrder order) {
    _order = order;
    return this;
  }

  TotalCardPay setPayer(TotalpayPayer payer) {
    _payer = payer;
    return this;
  }

  TotalCardPay onTransactionFailure(
      Function(TotalpayTransactionDetailsSuccess response) callback) {
    _onTransactionFailure = callback;
    return this;
  }

  TotalCardPay onTransactionSuccess(
      Function(TotalpayTransactionDetailsSuccess response) callback) {
    _onTransactionSuccess = callback;
    return this;
  }

  TotalCardPay onError(Function(dynamic response) callback) {
    _onError = callback;
    return this;
  }

  TotalCardPay onPresent(Function(BuildContext context) callback) {
    _onPresent = callback;
    return this;
  }

  initialize(BuildContext context) {
    TotalpaySdk.instance.ADAPTER.CARD_PAY.execute(
        order: _order!,
        payer: _payer!,
        callback: CardPayResponseCallback(
            success: (TotalpayTransactionDetailsSuccess response) {
          Log(response.toJson().toString());
          _onTransactionSuccess!(response);
        }, failure: (TotalpayTransactionDetailsSuccess response) {
          Log(response.toJson().toString());
          _onTransactionFailure!(response);
        }, error: (TotalpayError error) {
          _onError!(error);
        }),
        onFailure: (err) {});
    Future.delayed(const Duration(milliseconds: 200)).then((value) {
      if (_onPresent != null) {
        _onPresent!(context);
      }
    });
  }

  Widget widget() {
    return const SizedBox();
  }
}
