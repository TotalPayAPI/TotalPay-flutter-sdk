import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/src/adapters/callbacks/CardPayResponseCallback.dart';

class TotalCardPayResult {
  TotalpayTransactionDetailsSuccess? success;
  TotalpayTransactionDetailsSuccess? failure;
  TotalpayError? error;

  TotalCardPayResult(Map result) {
    if (result.containsKey("success")) {
      success = TotalpayTransactionDetailsSuccess.fromJson(result["success"]);
    }
    if (result.containsKey("failure")) {
      failure = TotalpayTransactionDetailsSuccess.fromJson(result["failure"]);
    }

    if (result.containsKey("error")) {
      error = TotalpayError.fromJson(result["error"]);
    }
  }

  triggerCallbacks(CardPayResponseCallback? callback,
      {Function(dynamic)? onFailure}) {
    if (success != null) {
      callback?.success(success!);
    }

    if (failure != null) {
      callback?.failure(failure!);
    }

    if (error != null) {
      callback?.error(error!);
    }
  }
}
