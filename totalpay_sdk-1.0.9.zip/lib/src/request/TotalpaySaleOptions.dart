import 'dart:convert';

class TotalpaySaleOption {
  String? channelId;
  bool? recurringInit;

  TotalpaySaleOption({required this.channelId, required this.recurringInit});

  TotalpaySaleOption.fromJson(dynamic json) {
    channelId = json['channelId'];
    recurringInit = json['recurringInit'];
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['channelId'] = channelId;
    map['recurringInit'] = recurringInit;
    return map;
  }

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
