import 'dart:convert';

import 'package:totalpay_sdk/src/api/TotalpayResult.dart';

import 'TotalpayExactError.dart';

class TotalpayError {
  TotalpayResult? result;
  num? errorCode;
  String? errorMessage;
  List<TotalpayExactError>? errors;

  TotalpayError({
    this.result,
    this.errorCode,
    this.errorMessage,
    this.errors,
  });

  TotalpayError.fromJson(dynamic json) {
    result = TotalpayResult.of(json['result']);
    errorCode = json['error_code'];
    errorMessage = json['error_message'];

    if (json['errors'] != null) {
      errors = [];
      json['errors'].forEach((v) {
        errors?.add(TotalpayExactError.fromJson(v));
      });
    }
  }
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['result'] = result?.result;
    map['error_code'] = errorCode;
    map['error_message'] = errorMessage;
    if (errors != null) {
      map['errors'] = errors?.map((v) => v.toJson()).toList();
    }
    return map;
  }

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
