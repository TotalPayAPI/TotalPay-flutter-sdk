mixin TotalpayResponse {}
