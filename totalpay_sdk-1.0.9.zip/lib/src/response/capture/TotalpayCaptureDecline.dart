import 'dart:convert';

import 'package:totalpay_sdk/src/response/base/result/IDetailsTotalpayResult.dart';

class TotalpayCaptureDecline extends IDetailsTotalpayResult {
  String? declineReason;

  TotalpayCaptureDecline.fromJson(dynamic json) : super.fromJson(json) {
    declineReason = json['decline_reason'];
  }

  @override
  Map<String, dynamic> toJson() {
    final map = super.toJson();
    map['decline_reason'] = declineReason;
    return map;
  }

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
