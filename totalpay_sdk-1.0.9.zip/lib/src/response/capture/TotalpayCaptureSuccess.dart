import 'dart:convert';

import 'package:totalpay_sdk/src/response/base/result/IDetailsTotalpayResult.dart';

class TotalpayCaptureSuccess extends IDetailsTotalpayResult {
  TotalpayCaptureSuccess.fromJson(dynamic json) : super.fromJson(json);

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
