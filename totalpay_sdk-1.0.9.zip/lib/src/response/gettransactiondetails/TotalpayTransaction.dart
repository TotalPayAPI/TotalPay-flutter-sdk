import 'package:totalpay_sdk/src/api/TotalpayTransactionStatus.dart';
import 'package:totalpay_sdk/src/api/TotalpayTransactionType.dart';

class TotalpayTransaction {
  String? date;
  TotalpayTransactionType? type;
  TotalpayTransactionStatus? status;
  double? amount;

  TotalpayTransaction({
    this.date,
    this.type,
    this.status,
    this.amount,
  });

  TotalpayTransaction.fromJson(dynamic json) {
    date = json['date'];
    type = TotalpayTransactionType.of(json['type'].toString());
    status = TotalpayTransactionStatus.of(json['status'].toString());
    amount = json['amount'];
  }

  Map<String?, dynamic> toJson() {
    final map = <String?, dynamic>{};
    map['date'] = date;
    map['type'] = type;
    map['status'] = status;
    map['amount'] = amount;
    return map;
  }
}
