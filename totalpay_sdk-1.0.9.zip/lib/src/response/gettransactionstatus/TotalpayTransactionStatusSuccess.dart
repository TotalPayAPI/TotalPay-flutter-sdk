import 'dart:convert';

import 'package:totalpay_sdk/src/response/base/result/ITotalpayResult.dart';

class TotalpayTransactionStatusSuccess extends ITotalpayResult {
  TotalpayTransactionStatusSuccess.fromJson(dynamic json)
      : super.fromJson(json);

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
