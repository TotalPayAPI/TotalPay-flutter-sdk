mixin TotalPaySaleResponse {}
