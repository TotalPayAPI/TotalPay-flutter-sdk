import 'package:totalpay_sdk/totalpay_sdk.dart';

class TotalpaySaleResult {
  TotalpaySaleSuccess? success;
  TotalpaySaleRedirect? redirect;
  TotalpaySale3DS? secure3d;
  TotalpaySaleRecurring? recurring;
  TotalpaySaleDecline? decline;
  TotalpayError? error;
  dynamic failure;
  Map? responseJSON;

  TotalpaySaleResult(Map result) {
    if (result.containsKey("success")) {
      success = TotalpaySaleSuccess.fromJson(result["success"]);
    }

    if (result.containsKey("redirect")) {
      redirect = TotalpaySaleRedirect.fromJson(result["redirect"]);
    }

    if (result.containsKey("secure3d")) {
      secure3d = TotalpaySale3DS.fromJson(result["secure3d"]);
    }

    if (result.containsKey("recurring")) {
      recurring = TotalpaySaleRecurring.fromJson(result["recurring"]);
    }

    if (result.containsKey("decline")) {
      decline = TotalpaySaleDecline.fromJson(result["decline"]);
    }

    if (result.containsKey("error")) {
      error = TotalpayError.fromJson(result["error"]);
    }

    if (result.containsKey("failure")) {
      failure = result["failure"];
    }

    if (result.containsKey("responseJSON")) {
      responseJSON = result["responseJSON"];
    }
  }

  triggerCallbacks(SaleResponseCallback? callback,
      {Function(dynamic)? onFailure, Function(Map)? onResponseJSON}) {
    if (success != null) {
      callback?.success(success!);
    }

    if (redirect != null) {
      callback?.redirect(redirect!);
    }

    if (recurring != null) {
      callback?.recurring(recurring!);
    }

    if (secure3d != null) {
      callback?.secure3d(secure3d!);
    }

    if (decline != null) {
      callback?.decline(decline!);
    }

    if (error != null) {
      callback?.error(error!);
    }

    if (failure != null && onFailure != null) {
      onFailure(failure);
    }

    if (responseJSON != null && onResponseJSON != null) {
      onResponseJSON(responseJSON ?? {});
    }
  }
}
