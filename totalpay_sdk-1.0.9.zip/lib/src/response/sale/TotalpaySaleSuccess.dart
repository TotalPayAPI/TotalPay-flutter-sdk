import 'dart:convert';

import 'package:totalpay_sdk/src/response/base/result/IDetailsTotalpayResult.dart';
import 'package:totalpay_sdk/src/response/sale/TotalPaySaleResponse.dart';

class TotalpaySaleSuccess extends IDetailsTotalpayResult
    with TotalPaySaleResponse {
  TotalpaySaleSuccess.fromJson(dynamic json) : super.fromJson(json);

  @override
  String toString() {
    return jsonEncode(toJson());
  }
}
