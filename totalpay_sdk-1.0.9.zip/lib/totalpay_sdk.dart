library intl;

import 'package:totalpay_sdk/src/Helpers.dart';
import 'package:totalpay_sdk/src/adapters/TotalPayAdapters.dart';

import 'totalpay_sdk_platform_interface.dart';

import 'dart:async';

export 'src/adapters/TotalPayAdapters.dart';
export 'src/adapters/callbacks/SaleResponseCallback.dart';
export 'src/adapters/callbacks/RecurringSaleResponseCallback.dart';
export 'src/adapters/callbacks/CaptureResponseCallback.dart';
export 'src/adapters/callbacks/CreditVoidResponseCallback.dart';
export 'src/adapters/callbacks/TransactionStatusResponseCallback.dart';
export 'src/adapters/callbacks/TransactionDetailsResponseCallback.dart';

export 'src/request/TotalpayCard.dart';
export 'src/request/TotalpayTestCards.dart';
export 'src/request/TotalpayOrder.dart';
export 'src/request/TotalpayPayer.dart';
export 'src/request/TotalpayPayerOption.dart';
export 'src/request/TotalpayRecurringOptions.dart';
export 'src/request/TotalpaySaleOptions.dart';
export 'src/request/TotalpaySaleOrder.dart';

export 'src/response/base/result/IDetailsTotalpayResult.dart';
export 'src/response/base/result/ITotalpayResult.dart';
export 'src/response/base/result/IOrderTotalpayResult.dart';

export 'src/response/base/error/TotalpayError.dart';
export 'src/response/base/error/TotalpayExactError.dart';

export 'src/response/capture/TotalpayCaptureSuccess.dart';
export 'src/response/capture/TotalpayCaptureDecline.dart';
export 'src/response/capture/TotalpayCaptureResult.dart';

export 'src/response/creditvoid/TotalpayCreditvoidSuccess.dart';
export 'src/response/creditvoid/TotalpayCreditVoidResult.dart';

export 'src/response/gettransactiondetails/TotalpayTransaction.dart';
export 'src/response/gettransactiondetails/TotalpayTransactionDetailsSuccess.dart';
export 'src/response/gettransactiondetails/TotalpayTransactionDetailResult.dart';

export 'src/response/gettransactionstatus/TotalpayTransactionStatusSuccess.dart';
export 'src/response/gettransactionstatus/TotalpayTransactionStatusResult.dart';

export 'src/response/sale/TotalpayRedirectParams.dart';
export 'src/response/sale/TotalpaySale3DS.dart';
export 'src/response/sale/TotalpaySale3dsRedirectParams.dart';
export 'src/response/sale/TotalpaySaleDecline.dart';
export 'src/response/sale/TotalpaySaleRecurring.dart';
export 'src/response/sale/TotalpaySaleRedirect.dart';
export 'src/response/sale/TotalpaySaleSuccess.dart';
export 'src/response/sale/TotalpaySaleResult.dart';

export 'src/cardpay/TotalCardPay.dart';
export 'src/applepay/TotalApplePay.dart';

export 'src/api/TotalpayAction.dart';
export 'src/api/TotalpayStatus.dart';
export 'src/api/TotalpayResult.dart';

class TotalpaySdk {
  static final TotalpaySdk _instance = TotalpaySdk();
  static TotalpaySdk get instance => _instance;

  Future<String?> getPlatformVersion() {
    return TotalpaySdkPlatform.instance.getPlatformVersion();
  }

  Future<bool> config(
      {required String key,
      required String password,
      bool enableDebug = false}) {
    return TotalpaySdkPlatform.instance.config(key, password, enableDebug);
  }

  TotalPayAdapters ADAPTER = TotalPayAdapters();
  Helpers HELPER = Helpers();
}
