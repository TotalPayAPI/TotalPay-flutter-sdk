import 'package:plugin_platform_interface/plugin_platform_interface.dart';

import 'totalpay_sdk_method_channel.dart';

abstract class TotalpaySdkPlatform extends PlatformInterface {
  /// Constructs a TotalpaySdkPlatform.
  TotalpaySdkPlatform() : super(token: _token);

  static final Object _token = Object();

  static TotalpaySdkPlatform _instance = MethodChannelTotalpaySdk();

  /// The default instance of [TotalpaySdkPlatform] to use.
  ///
  /// Defaults to [MethodChannelTotalpaySdk].
  static TotalpaySdkPlatform get instance => _instance;

  /// Platform-specific implementations should set this with their own
  /// platform-specific class that extends [TotalpaySdkPlatform] when
  /// they register themselves.
  static set instance(TotalpaySdkPlatform instance) {
    PlatformInterface.verifyToken(instance, _token);
    _instance = instance;
  }

  Future<String?> getPlatformVersion() {
    throw UnimplementedError('platformVersion() has not been implemented.');
  }

  Future<bool> config(String key, String password, bool enableDebug) {
    throw UnimplementedError('config() has not been implemented.');
  }
}
