import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:totalpay_sdk/totalpay_sdk_method_channel.dart';

void main() {
  MethodChannelTotalpaySdk platform = MethodChannelTotalpaySdk();
  const MethodChannel channel = MethodChannel('totalpay_sdk');

  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    channel.setMockMethodCallHandler((MethodCall methodCall) async {
      return '42';
    });
  });

  tearDown(() {
    channel.setMockMethodCallHandler(null);
  });

  test('getPlatformVersion', () async {
    expect(await platform.getPlatformVersion(), '42');
  });
}
