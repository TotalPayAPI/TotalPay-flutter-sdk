import 'package:flutter_test/flutter_test.dart';
import 'package:totalpay_sdk/totalpay_sdk.dart';
import 'package:totalpay_sdk/totalpay_sdk_platform_interface.dart';
import 'package:totalpay_sdk/totalpay_sdk_method_channel.dart';
import 'package:plugin_platform_interface/plugin_platform_interface.dart';

class MockTotalpaySdkPlatform
    with MockPlatformInterfaceMixin
    implements TotalpaySdkPlatform {
  @override
  Future<String?> getPlatformVersion() => Future.value('42');

  @override
  Future<bool> config(String key, String password, bool enableDebug) {
    throw UnimplementedError();
  }
}

void main() {
  final TotalpaySdkPlatform initialPlatform = TotalpaySdkPlatform.instance;

  test('$MethodChannelTotalpaySdk is the default instance', () {
    expect(initialPlatform, isInstanceOf<MethodChannelTotalpaySdk>());
  });

  test('getPlatformVersion', () async {
    TotalpaySdk totalpaySdkPlugin = TotalpaySdk();
    MockTotalpaySdkPlatform fakePlatform = MockTotalpaySdkPlatform();
    TotalpaySdkPlatform.instance = fakePlatform;

    expect(await totalpaySdkPlugin.getPlatformVersion(), '42');
  });
}
